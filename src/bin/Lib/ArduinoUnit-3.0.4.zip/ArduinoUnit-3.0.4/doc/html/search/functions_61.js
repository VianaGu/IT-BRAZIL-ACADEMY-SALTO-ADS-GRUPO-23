var searchData=
[
  ['available',['available',['../class_fake_stream.html#a425db0fb16e50da74ea573be6c655711',1,'FakeStream']]]
];
