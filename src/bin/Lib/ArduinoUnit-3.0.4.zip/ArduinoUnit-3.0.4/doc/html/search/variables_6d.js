var searchData=
[
  ['max_5fverbosity',['max_verbosity',['../class_test.html#aad3dc21628f5210b9ebdf843eb2b2ae0',1,'Test']]],
  ['min_5fverbosity',['min_verbosity',['../class_test.html#a1ff0e4cf27254c988233880fff9e6c6d',1,'Test']]]
];
