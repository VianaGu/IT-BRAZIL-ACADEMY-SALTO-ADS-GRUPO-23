var searchData=
[
  ['exclude',['exclude',['../class_test.html#a00269bd7c55b1c93477be06174280b04',1,'Test']]]
];
