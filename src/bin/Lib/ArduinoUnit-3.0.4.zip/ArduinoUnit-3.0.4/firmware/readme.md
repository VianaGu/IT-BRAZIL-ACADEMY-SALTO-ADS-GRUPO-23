ArduinoUnit 2.0 Firmware
========================

Firmware for testing ArduinoUnit 2.0 using ArduinoUnit 2.0.  This firmware
is of interest to developers of ArduinoUnit, not developers using ArduinoUnit.

The firmware is interactive --- you must choose a test configuration before
running some tests.  You can execute the default configuration by typing
'run' in the serial port monitor (115200 baud, send Newlines), but you can
interactively select and remove tests, and adjust overall verbosity before
running the active tests.
